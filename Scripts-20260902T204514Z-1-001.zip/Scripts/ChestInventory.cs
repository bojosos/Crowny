﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ChestInventory : Inventory
{

    public ChestInventory(GameObject i)
        : base(i)
    {
    }

    protected override void Start()
    {
        //Test();
    }

    public override void GetOwnSlots()
    {
        itemInHand.image = inventoryUI.transform.GetChild(1).GetComponent<Image>();
        itemInHand.text = itemInHand.image.GetComponentInChildren<Text>();
        selected = inventoryUI.transform.GetChild(2).gameObject;
        info = inventoryUI.transform.GetChild(3).gameObject;
        Transform background = inventoryUI.transform.GetChild(0);
        Transform inv = background.GetChild(0);
        Transform playerSlots = inv.GetChild(1);
        Transform chestSlots = inv.GetChild(0);
        List<Image> tmp = new List<Image>();

        inventory = new Slot[chestSlots.childCount + playerSlots.childCount];
        for (int i = 0; i < chestSlots.childCount; i++)
        {
            tmp.Add(chestSlots.GetChild(i).GetChild(0).GetComponent<Image>());
        }
        for (int i = 0; i < playerSlots.childCount; i++)
        {
            tmp.Add(playerSlots.GetChild(i).GetChild(0).GetComponent<Image>());
        }
        for (int i = 0; i < tmp.Count; i++)
        {
            inventory[i].image = tmp[i];
        }
    }

    public override void SetChestItems(Item[] items)
    {
        update = true;
        for (int i = 0; i < items.Length; i++)
        {
            inventory[i].item = items[i];
            if (inventory[i].item.amount == 0)
            {
                inventory[i].TurnOff();
            }
        }
    }

    public override void SetPlayerItems(Item[] items)
    {
        update = true;
        for (int i = 27; i < 27 + items.Length; i++)
        {
            inventory[i].item = items[i];
            if (inventory[i].item.amount == 0)
            {
                inventory[i].TurnOff();
            }
        }
    }

    public override Item[] GetPlayerItems()
    {
        List<Item> tmp = new List<Item>();
        for (int i = 27; i < inventory.Length; i++)
        {
            tmp.Add(inventory[i].item);
        }
        return tmp.ToArray();
    }

}