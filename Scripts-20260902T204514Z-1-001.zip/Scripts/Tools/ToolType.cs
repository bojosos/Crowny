﻿public enum ToolType
{
	Pickaxe,
	Shovel,
	Axe}
;