using UnityEngine;
using UnityEngine.UI;

public class UIManager
{
	
	public static Sprite[] stages;
    public static Image[] blockSides;
    public static Image[] highlights;
    public static GameObject[] ingameSlots;
    public static TextMesh InfoText;

    public static void Start (Sprite[] s, Image[] i, Image[] high, GameObject[] slots,TextMesh text)
	{
		stages = s;
        blockSides = i;
        ingameSlots = slots;
        highlights = high;
        InfoText = text;
		UIManager.blockSides [0].transform.rotation = Quaternion.Euler (90, 0, 0);
		UIManager.blockSides [1].transform.rotation = Quaternion.Euler (90, 0, 0);
		UIManager.blockSides [4].transform.rotation = Quaternion.Euler (0, 90, 0);
		UIManager.blockSides [5].transform.rotation = Quaternion.Euler (0, 90, 0);


        UIManager.highlights [0].transform.rotation = Quaternion.Euler (90, 0, 0);
        UIManager.highlights [1].transform.rotation = Quaternion.Euler (90, 0, 0);
        UIManager.highlights [4].transform.rotation = Quaternion.Euler (0, 90, 0);
        UIManager.highlights [5].transform.rotation = Quaternion.Euler (0, 90, 0);

	}

}