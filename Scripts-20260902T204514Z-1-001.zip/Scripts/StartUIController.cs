﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections.Generic;
using System.IO;
using System.Net.Configuration;
using System;

public class StartUIController : MonoBehaviour
{

    public GameObject options;
    public GameObject mainMenu;
    public GameObject worldList;
    public Text FOVValue;
    public Slider FOVSlider;

    public GameObject singlePlayerButton;

    private List<Button> buttons = new List<Button>();

    public float buttonYSpacing = 5;
    public float buttonXSpacing = 5;
    public float buttonHeight;
    public float buttonWidth;

    public float firstButtonX;
    public float firstButtonY;

    public GameObject worldElement;

    public string[] files;

    private int cnt = 0;

    void LoadWorlds()
    {
        string dir = "minecraftSave";
        files = Directory.GetDirectories(dir);
        for (int i = 0; i < files.Length; i++)
            files[i] = files[i].Replace(dir + "\\", "");
    }

    void GenerateButtons()
    {
        if (files.Length == 0)
            return;
        firstButtonX = singlePlayerButton.transform.position.x;
        firstButtonY = singlePlayerButton.transform.position.y;
        buttonWidth = singlePlayerButton.GetComponent<RectTransform>().rect.width;
        buttonHeight = singlePlayerButton.GetComponent<RectTransform>().rect.height;

        float currentX = firstButtonX + buttonXSpacing + buttonWidth, currentY = firstButtonY;
        Button b = ((GameObject)(Instantiate(singlePlayerButton, new Vector3(currentX, currentY, 0), Quaternion.identity))).GetComponent<Button>();
        b.GetComponent<RectTransform>().sizeDelta = new Vector2(buttonWidth, buttonHeight);
        buttons.Add(b);
        b.transform.SetParent(mainMenu.transform);
        float rx = currentX;
        float ry = currentY;
        int worldsOnTop = (files.Length - 1) / 2;
        int worldsOnBottom = files.Length - 1 - worldsOnTop;
        buttons[cnt].GetComponentInChildren<Text>().text = files[cnt];

        cnt = 1;
        for (int i = 0; i < worldsOnTop; i++, cnt++)
        {
            currentX = currentX;
            currentY = currentY + buttonHeight + buttonYSpacing;
            b = ((GameObject)(Instantiate(singlePlayerButton, new Vector3(currentX, currentY, 0), Quaternion.identity))).GetComponent<Button>();
            b.GetComponent<RectTransform>().sizeDelta = new Vector2(buttonWidth, buttonHeight);
            buttons.Add(b);
            b.transform.SetParent(mainMenu.transform);
        }
        currentX = rx;
        currentY = ry;
        for (int i = 0; i < worldsOnBottom; i++)
        {
            currentX = currentX;
            currentY = currentY - buttonHeight - buttonYSpacing;
            b = ((GameObject)(Instantiate(singlePlayerButton, new Vector3(currentX, currentY, 0), Quaternion.identity))).GetComponent<Button>();
            b.GetComponent<RectTransform>().sizeDelta = new Vector2(buttonWidth, buttonHeight);
            buttons.Add(b);
            b.transform.SetParent(mainMenu.transform);
        }

        foreach (Button b1 in buttons)
            b1.gameObject.SetActive(false);
    }

    void Start()
    {
        LoadWorlds();

    }

    void FOVChaned(float f)
    {
        FOVValue.text = f.ToString();
        Camera.main.fieldOfView = f;
    }

    public void Singleplayer()
    {
        DisplayWorlds();
        worldList.SetActive(!worldList.activeSelf);
        foreach (Button b in buttons)
        {
            b.gameObject.SetActive(!b.IsActive());
        }
    }

    private void DisplayWorlds()
    {
        foreach (string file in files)
        {
            WorldElement we = ((GameObject)Instantiate(worldElement)).GetComponent<WorldElement>();
            we.SetInfo(file, "Today", "888888", "1");
        }
    }

    public void Options()
    {
        options.SetActive(true);
        mainMenu.SetActive(false);
    }

    public void BackToMenuScreen()
    {
        options.SetActive(false);
        mainMenu.SetActive(true);
    }

    public void Quit()
    {
        Application.Quit();
    }

}
