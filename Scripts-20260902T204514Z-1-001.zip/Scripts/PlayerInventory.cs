﻿using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.Characters.FirstPerson;
using System.Collections.Generic;

public class PlayerInventory : Inventory
{


    public PlayerInventory(GameObject t)
        : base(t)
    {
    }

    protected override void Start()
    {
        Test();
        inventory[0].item.slotType = SlotType.Helmet;
        inventory[1].item.slotType = SlotType.Chestplate;
        inventory[2].item.slotType = SlotType.Pants;
        inventory[3].item.slotType = SlotType.Boots;
    }

    public override void GetOwnSlots()
    {
        itemInHand.image = inventoryUI.transform.GetChild(1).GetComponent<Image>();
        itemInHand.text = itemInHand.image.GetComponentInChildren<Text>();
        selected = inventoryUI.transform.GetChild(2).gameObject;
        info = inventoryUI.transform.GetChild(3).gameObject;
        Transform background = inventoryUI.transform.GetChild(0);
        Transform inv = background.GetChild(0);
        Transform playerInfo = inv.GetChild(0);
        Transform armorSlots = playerInfo.GetChild(0);

        Transform playerSlots = inv.GetChild(1);

        List<Image> tmp = new List<Image>();


        inventory = new Slot[playerSlots.childCount + armorSlots.childCount];

        for (int i = 0; i < armorSlots.childCount; i++)
        {
            tmp.Add(armorSlots.GetChild(i).GetChild(0).GetComponent<Image>());
        }
        for (int i = 0; i < playerSlots.childCount; i++)
        {
            tmp.Add(playerSlots.GetChild(i).GetChild(0).GetComponent<Image>());
        }
        for (int i = 0; i < tmp.Count; i++)
        {
            inventory[i].image = tmp[i];
            inventory[i].text = tmp[i].GetComponentInChildren<Text>();
        }
    }

    private Slot t;

    protected override void MoveItemsToHotBar(int index, int start = 27)
    {
        if (!enabled)
            return;
        
        if (inventory[index].item.IsArmor())
        {
            if (index > 3)
            {
                t = itemInHand;
                itemInHand.item.SetToNull();
                if (inventory[index].item.slotType == SlotType.Helmet && inventory[0].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(0);
                }
                else if (inventory[index].item.slotType == SlotType.Chestplate && inventory[1].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(1);
                }
                else if (inventory[index].item.slotType == SlotType.Pants && inventory[2].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(2);
                }
                else if (inventory[index].item.slotType == SlotType.Boots && inventory[3].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(3);
                }
                else
                    MoveItemsToHotBarBase(index, start + 4);
                itemInHand = t;
                if (!itemInHand.Empty)
                    itemInHand.TurnOn();
            }
            else
            {
                t = itemInHand;
                itemInHand.item.SetToNull();
                GrabFullStack(index);
                for (int i = 4; i < inventory.Length; i++)
                {
                    Debug.Log(inventory[i].item.name);
                    if (inventory[i].Empty)
                    {
                        Debug.Log(inventory[i].slotType);
                        PlaceItemInSlot(i);
                        itemInHand = t;
                        if (!itemInHand.Empty)
                            itemInHand.TurnOn();
                        return;
                    }
                }
            }
        }
        else
            MoveItemsToHotBarBase(index, start + 4);
        //MoveItemsToHotBarBase(index,start+4);
    }

    protected override void MoveItemsToInventory(int index, int start = 0)
    {
        if (!enabled)
            return;
        if (inventory[index].item.IsArmor())
        {
            if (index > 3)
            {
                if (inventory[index].item.slotType.Equals(ArmorType.Helmet) && inventory[0].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(0);
                }
                else if (inventory[index].item.slotType.Equals(ArmorType.Chestplate) && inventory[1].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(1);
                }
                else if (inventory[index].item.slotType.Equals(ArmorType.Pants) && inventory[2].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(2);
                }
                else if (inventory[index].item.slotType.Equals(ArmorType.Boots) && inventory[3].Empty)
                {
                    GrabFullStack(index);
                    PlaceItemInSlot(3);
                }
                else
                    MoveItemsToInventoryBase(index, start);
            }
            else
            {
                GrabFullStack(index);
                Debug.Log(2);
                for (int i = 4; i < inventory.Length; i++)
                {
                    if (inventory[i].Empty)
                    {
                        PlaceItemInSlot(i);
                        return;
                    }
                }
            }
        }
        else
            MoveItemsToInventoryBase(index, start);
    }

    protected override void OnShiftPress(int index)
    {
        if (!enabled)
            return;
        update = true;
        if (index < 31)
            MoveItemsToHotBar(index);
        else
            MoveItemsToInventory(index);
    }

}