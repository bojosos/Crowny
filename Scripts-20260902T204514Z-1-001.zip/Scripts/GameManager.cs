﻿using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.Characters.FirstPerson;
using System.IO;

public class GameManager : MonoBehaviour
{
    [Header("Block Inventory Sprites")]
    public Sprite AirSprite;
    public Sprite DirtSprite;
    public Sprite GrassSprite;
    public Sprite CobblestoneSprite;
    public Sprite StoneBrickSprite;
    public Sprite HalfSlabSprite;
    public Sprite DiamondHelmet;
    public Sprite DiamondChestplate;
    public Sprite DiamondPants;
    public Sprite DiamondBoots;

    [Header("Block Breaking Stages")]
    public Sprite[] stages = new Sprite[10];
    public Image[] images = new Image[6];

    [Header("Ingame Item Slots")]
    public GameObject[] slots;

    [Header("Inventories")]
    public GameObject playerInventory;
    public GameObject chestInventory;
    public Image itemInHand;
    public GameObject info;
    public GameObject selectedSprite;

    [Header("Player Cursor")]
    public GameObject cursor;

    private Inventory playerInv;
    private Inventory chestInv;

    [Header("Player")]
    public GameObject fps;

    [Header("Highlighting")]
    public Image[] highlights;

    [Header("Block info")]
    public TextMesh infoText;

    public static GameManager instance;

    public static int selected;

    public bool activeInventory
    {
        get
        {
            return chestInv.enabled || playerInv.enabled;
        }
    }

    void OnEnable()
    {
        instance = this;
        InitializeSprites();
        InitializeUIManager();
        chestInv = new ChestInventory(chestInventory);
        playerInv = new PlayerInventory(playerInventory);
        //playerInv.SetItems(); // Load from a file
        chestInv.enabled = false;
    }

    void InitializeSprites()
    {
        Sprite[] sprites = { AirSprite, DirtSprite, GrassSprite, CobblestoneSprite, StoneBrickSprite, HalfSlabSprite, DiamondHelmet, DiamondChestplate, DiamondPants, DiamondBoots };
        ItemList.Start(sprites); // Instaniciate all of the item stuff
    }

    void InitializeUIManager()
    {
        UIManager.Start(stages, images, highlights, slots,infoText);
    }

    void Update()
    {
        if (chestInv.enabled)
            chestInv.Update();
        else
            playerInv.Update();
        if (Input.GetKeyDown(KeyCode.E))
        {
            OnEPress();
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            OnEscapePress();
        }
    }

    void ToggleChestInventory()
    {
        chestInventory.SetActive(!chestInventory.activeSelf);
    }

    public void SavePlayerItems()
    {
        if (chestInv.enabled)
            playerInv.SetPlayerItems(chestInv.GetPlayerItems());
        FileUtils.SavePlayerInventory(playerInv, "test");
    }

    void OnEscapePress()
    {
        if (chestInv.enabled)
        {
            chestInv.enabled = false;
            chestInventory.SetActive(false);
            playerInv.SetPlayerItems(chestInv.GetPlayerItems());
            UpdateHotBar();
            fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(true);
            fps.GetComponent<FirstPersonController>().enabled = true;
        }
        if (playerInv.enabled)
        {
            playerInv.enabled = false;
            playerInventory.SetActive(false);
            UpdateHotBar();
            fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(true);
            fps.GetComponent<FirstPersonController>().enabled = true;
        }
    }

    void OnEPress()
    {
        if (chestInv.enabled)
        {
            chestInv.enabled = false;
            chestInventory.SetActive(false);
            playerInv.SetPlayerItems(chestInv.GetPlayerItems());
            UpdateHotBar();
            fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(true);
            fps.GetComponent<FirstPersonController>().enabled = true;
            return;
        }
        if (!playerInv.enabled) // Open inventory
        {
            fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(false);
            fps.GetComponent<FirstPersonController>().enabled = false;
            cursor.SetActive(false);
            playerInventory.SetActive(true);
            playerInv.enabled = true;
        }
        else // Close inventory
        {
            cursor.SetActive(true);
            playerInv.enabled = false;
            fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(true);
            fps.GetComponent<FirstPersonController>().enabled = true;
            UpdateHotBar();
            playerInventory.SetActive(false);
        }
    }

    public void OpenChest(Item[] items)
    {
        chestInv.enabled = true;
        chestInventory.SetActive(true);
        chestInv.SetChestItems(items);
        chestInv.SetPlayerItems(playerInv.GetPlayerItems());
        fps.GetComponent<FirstPersonController>().m_MouseLook.SetCursorLock(false);
        fps.GetComponent<FirstPersonController>().enabled = false;
    }

    void UpdateHotBar()
    {
        for (int i = 0; i < 9; i++)
        {
            UIManager.ingameSlots[i].transform.GetChild(0).GetComponent<Image>().sprite = playerInv.inventory[Statics.HotToSlot(i, 4)].item.sprite;
            UIManager.ingameSlots[i].transform.GetChild(1).GetComponent<Text>().text = playerInv.inventory[Statics.HotToSlot(i, 4)].item.amount.ToString();
            UIManager.ingameSlots[i].transform.GetChild(1).GetComponent<Text>().gameObject.SetActive(true);
            UIManager.ingameSlots[i].transform.GetChild(0).GetComponent<Image>().color = playerInv.max;
            if (playerInv.inventory[Statics.HotToSlot(i, 4)].item.amount <= 0)
            {
                UIManager.ingameSlots[i].transform.GetChild(0).GetComponent<Image>().color = playerInv.min;
                UIManager.ingameSlots[i].transform.GetChild(1).gameObject.SetActive(false);
            }
        }
    }

    public Block GetHotbarBlock(int x,int y,int z,int selected, bool up = false)
    {
        playerInv.inventory[Statics.HotToSlot(selected, 4)].item.amount--;
        if (playerInv.inventory[Statics.HotToSlot(selected, 4)].item.amount == 0)
        {
            Block res = null;
            switch (playerInv.inventory[Statics.HotToSlot(selected, 4)].item.data.blockType)
            {
                case TypeBlock.BlockAir:
                    res = new BlockAir(x, y, z);
                    break;
                case TypeBlock.BlockCobblestone:
                    res = new BlockStone(x,y,z);
                    break;
                case TypeBlock.BlockGrass:
                    res = new BlockGrass(x, y, z);
                    break;
                case TypeBlock.BlockStoneBrick:
                    res = new CobblestoneSlab(x, y, z,up);
                    break;
                case TypeBlock.CobblestoneSlab:
                    res = new HalfBlock(x, y, z,up);
                    break;
            }
            playerInv.inventory[Statics.HotToSlot(selected, 4)].TurnOff();
            UIManager.ingameSlots[selected].transform.GetChild(0).GetComponent<Image>().sprite = playerInv.inventory[Statics.HotToSlot(selected, 4)].item.sprite;
            UIManager.ingameSlots[selected].transform.GetChild(0).GetComponent<Image>().color = playerInv.min;
            UIManager.ingameSlots[selected].transform.GetChild(1).gameObject.SetActive(false); // Turn off text
            return res;
        }
        if (playerInv.inventory[Statics.HotToSlot(selected, 4)].item.amount < 0)
        {
            return null;
        }
        UIManager.ingameSlots[selected].transform.GetChild(1).GetComponent<Text>().text = playerInv.inventory[Statics.HotToSlot(selected, 4)].item.amount.ToString();
        switch (playerInv.inventory[Statics.HotToSlot(selected, 4)].item.data.blockType)
        {
            case TypeBlock.BlockAir:
                return new BlockAir(x, y, z);
            case TypeBlock.BlockCobblestone:
                return new BlockStone(x,y,z);
            case TypeBlock.BlockGrass:
                return new BlockGrass(x, y, z);
            case TypeBlock.BlockStoneBrick:
                return new CobblestoneSlab(x, y, z,up);
            case TypeBlock.CobblestoneSlab:
                return new HalfBlock(x, y, z,up);
        }
        return null;
    }

}