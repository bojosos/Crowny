﻿using UnityEngine;
using UnityEngine.UI;
using System.Linq;
public class Inventory
{

    public Slot[] inventory;

    protected Slot itemInHand;

    protected int lastClickedIndex;
    protected GameObject inventoryUI;

    protected bool update = true;
    public bool enabled = false;

    protected float lastClickTime;
    protected float timeTreshold = 0.2f;

    public Color max;
    public Color min;

    protected int currentHover;
    protected GameObject selected;

    protected GameObject info;
    protected Text infoName;
    protected Text infoId;
    protected Text infoDescr;

    public Inventory(GameObject i)
    {
        Init(i);
        enabled = true;
    }

    protected virtual void Start()
    {
    }

    public void Init(GameObject i)
    {
        inventoryUI = i;
        GetOwnSlots();
        infoName = info.transform.GetChild(0).GetChild(0).GetComponent<Text>();
        infoId = info.transform.GetChild(0).GetChild(1).GetComponent<Text>();
        infoDescr = info.transform.GetChild(1).GetComponent<Text>();
        itemInHand.TurnOff();
        AddPlayerInvListeners();
        AddForeignListeners();
        max = new Color(255, 255, 255, 255);
        min = new Color(0.01f, 0.01f, 0.01f, 0.01f);
        Start();
        for (int f = 0; f < inventory.Length; f++)
        {
            inventory[f].slotType = inventory[f].item.slotType;
        }
    }

    public virtual Item[] GetPlayerItems()
    {
        return inventory.Select(x => x.item).ToArray();
    }

    public virtual void SetChestItems(Item[] items)
    {
        for (int i = 0; i < items.Length; i++)
        {
            inventory[i].item = items[i];
        }
        for (int i = 0; i < inventory.Length; i++)
        {
            inventory[i].item.sprite = inventory[i].item.sprite;
            if (inventory[i].item.amount == 0)
            {
                inventory[i].TurnOff();
            }
        }
    }

    public virtual void SetPlayerItems(Item[] items)
    {
        for (int i = 0; i < items.Length; i++)
        {
            inventory[i].item = items[i];
        }
        for (int i = 0; i < inventory.Length; i++)
        {
            inventory[i].image.sprite = inventory[i].item.sprite;
            if (inventory[i].item.amount == 0)
            {
                inventory[i].TurnOff();
            }
        }
    }

    protected virtual void AddPlayerInvListeners()
    {
        for (int i = 0; i < inventory.Length; i++)
        {
            int n = i;
            Button2 b = inventory[n].image.GetComponent<Button2>();
            b.AddLeftClickListener(() => OnLeftClicked(n));
            b.AddRightClickListener(() => OnRightClicked(n));
            b.AddHoverExitListener(() => OnHoverExit(n));
            b.AddHoverChangeListener(() => OnHoverChange(n));
            b.AddShiftPressListener(() => OnShiftPress(n));
        }
    }

    protected virtual void AddForeignListeners()
    {
    }

    protected virtual void OnShiftPress(int index)
    {
        if (!enabled)
            return;
        update = true;
        if (index < 27)
            MoveItemsToHotBar(index);
        else
            MoveItemsToInventory(index);
    }

    protected virtual void OnHoverChange(int n)
    {
        if (!enabled)
            return;
        selected.SetActive(true);
        currentHover = n;
        selected.transform.position = inventory[n].image.transform.position;
        if (!inventory[n].Empty && itemInHand.Empty)
        {
            info.SetActive(true);
            infoName.text = inventory[currentHover].item.name;
            infoId.text = " (#00" + inventory[currentHover].item.data.id.ToString() + ")";
            infoDescr.text = inventory[currentHover].item.description;
        }
    }

    protected virtual void OnHoverExit(int n)
    {
        if (!enabled)
            return;
        currentHover = -1;
        selected.SetActive(false);
        info.SetActive(false);
    }


    protected virtual void Test()
    {
        for (int i = 0; i < inventory.Length; i++)
        {
            if (i < 9)
                inventory[i].item = ItemList.BlockGrass;
            else if (i < 18)
                inventory[i].item = ItemList.BlockCobblestone;
            else
                inventory[i].item = ItemList.BlockStonebrick;
            inventory[i].item.amount = 10;
            if (i < 4)
                inventory[i].item.amount = 1;
        }
        inventory[0].item = ItemList.DiamondHelmet;
        inventory[1].item = ItemList.DiamondChestplate;
        inventory[2].item = ItemList.DiamondPants;
        inventory[3].item = ItemList.DiamondBoots;
        for (int i = 0; i < inventory.Length; i++)
        {
            inventory[i].image.sprite = inventory[i].item.sprite;
            if (i > 4)
                inventory[i].item.slotType = SlotType.Anything;
        }
    }


    public virtual void GetOwnSlots()
    {
        itemInHand.image = inventoryUI.transform.GetChild(1).GetComponent<Image>();
        itemInHand.text = itemInHand.image.GetComponentInChildren<Text>();
        selected = inventoryUI.transform.GetChild(2).gameObject;
        info = inventoryUI.transform.GetChild(3).gameObject;
        Transform background = inventoryUI.transform.GetChild(0);
        Transform inv = background.GetChild(0);
        Transform slots = inv.GetChild(1);
        inventory = new Slot[slots.childCount];
        for (int i = 0; i < slots.childCount; i++)
        {
            inventory[i].image = slots.GetChild(i).GetChild(0).GetComponent<Image>();
            inventory[i].text = inventory[i].image.GetComponentInChildren<Text>();
        }
    }

    public virtual void GetOtherSlots()
    {
        
    }

    //TODO: Compare items not types
    protected virtual void OnLeftClicked(int index)
    {
        if (!enabled)
            return;
        update = true;
        CheckForDoubleClick(index);
        lastClickedIndex = index;
        lastClickTime = Time.time;
        ManageInventoryActions(index);
    }

    protected virtual void OnRightClicked(int index)
    {
        if (!enabled)
            return;
        update = true;
        if (itemInHand.Empty)
            GrabHalfStack(index);
        else
            LeaveOne(index);
    }

    protected virtual void LeaveOne(int index)
    {
        if (!enabled)
            return;
        if (inventory[index].item.data.Equals(itemInHand.item.data) && inventory[index].item.amount < inventory[index].item.data.maxItemsPerStack)
        {
            inventory[index].item.amount += 1;
            itemInHand.item.amount--;
            if (itemInHand.item.amount == 0)
            {
                itemInHand.TurnOff();
            }
            return;
        }
        if (inventory[index].Empty && Statics.CompareSlotTypes(itemInHand.slotType, inventory[index].slotType))
        {
            inventory[index].item = itemInHand.item;
            inventory[index].item.amount = 1;
            inventory[index].image.sprite = itemInHand.image.sprite;
            itemInHand.item.amount -= 1;
            inventory[index].TurnOn();
            if (itemInHand.item.amount == 0)
            {
                itemInHand.TurnOff();
            }
        }
    }

    void AddItemAtFirstAvailableSlot(Item item,int start = 0)
    {
        for(int i = start; i < inventory.Length; i++)
        {

        }
    }

    protected virtual void GrabHalfStack(int index)
    {
        if (!enabled)
            return;
        if (inventory[index].Empty) // if item in the slot is air
            return;
        itemInHand.item = inventory[index].item; // put the item in my hand
        itemInHand.image.sprite = inventory[index].item.sprite; // change the sprite of the item in my hand
        int t = inventory[index].item.amount;
        inventory[index].item.amount /= 2;
        itemInHand.item.amount = t - inventory[index].item.amount; // change the type of the block in my hand
        itemInHand.TurnOn();
        itemInHand.slotType = inventory[index].slotType;
        if (inventory[index].item.amount == 0)
            inventory[index].TurnOff();
    }

    protected virtual void ManageInventoryActions(int index)
    {
        if (!enabled)
            return;
        if (!itemInHand.Empty)
        {
            if (inventory[index].Empty)
            {
                PlaceItemInSlot(index);
            }
            else if (inventory[index].item.data.Equals(itemInHand.item.data))
            {
                CombineStacks(index);
            }
            else if (!inventory[index].item.data.Equals(itemInHand.item.data))
            {
                SwapStacks(index);
            }
        }
        else
        {
            GrabFullStack(index);
        }
    }

    protected virtual void CheckForDoubleClick(int index)
    {
        if (!enabled)
            return;
        if (!itemInHand.Empty)
        {
            if (lastClickedIndex == index)
            { // check if I clicked the same slot as before
                if (Time.time - lastClickTime < timeTreshold)
                { // check if I clicked fast enough
                    int cnt = itemInHand.item.amount;
                    for (int i = 0; i < inventory.Length; i++)
                    { // loop through all of the slots
                        if (inventory[i].item.data.Equals(itemInHand.item.data) && inventory[i].item.amount != inventory[i].item.data.maxItemsPerStack)
                        { // check if the item I clicked on is the same as the one in slot[i]

                            cnt += inventory[i].item.amount; // increase the counter with the items of the same type
                            if (cnt <= 64)
                                inventory[i].TurnOff();
                            else
                            {
                                cnt -= inventory[i].item.amount;
                                inventory[i].item.amount = inventory[i].item.amount - (inventory[i].item.data.maxItemsPerStack - cnt);
                                cnt = inventory[index].item.data.maxItemsPerStack;
                                break;
                            }
                        }
                    }
                    itemInHand.item.amount = cnt; // change the amount of items in my hand
                    itemInHand.TurnOn();
                    lastClickTime = -100000;
                    lastClickedIndex = 69;
                    return;
                }
            }
        }
    }

    protected virtual void MoveItemsToInventory(int index, int start = 0)
    {
        MoveItemsToInventoryBase(index, start);
    }

    protected virtual void MoveItemsToHotBar(int index, int start = 27)
    {
        MoveItemsToHotBarBase(index, start);
    }

    protected void MoveItemsToInventoryBase(int index, int start = 0)
    {
        if (!enabled)
            return;
        bool placed = false;
        for (int i = start; i < 27; i++)
        {
            if (inventory[i].item.data.Equals(inventory[index].item.data))
            {
                // fill to a stack
                placed = true;
                if (inventory[index].item.amount + inventory[i].item.amount <= inventory[index].item.data.maxItemsPerStack)
                {
                    inventory[i].item.amount += inventory[index].item.amount;
                    inventory[index].TurnOff();
                    break;
                }
                else
                {
                    int t = inventory[i].item.amount;
                    inventory[i].item.amount = inventory[index].item.data.maxItemsPerStack;
                    inventory[index].item.amount -= inventory[i].item.data.maxItemsPerStack - t;
                    MoveItemsToInventoryBase(index, i + 1);
                }
            }
        }
        if (!placed)
        {
            for (int i = 0; i < 31; i++)
            {
                if (inventory[i].Empty)
                {
                    inventory[i].item = inventory[index].item;
                    inventory[i].TurnOn();
                    inventory[index].TurnOff();
                    break;
                }
            }
        }
    }

    protected void MoveItemsToHotBarBase(int index, int start = 27)
    {
        if (!enabled)
            return;
        bool placed = false;
        for (int i = start; i < inventory.Length; i++)
        {
            if (inventory[i].item.data.Equals(inventory[index].item.data))
            {
                // fill to a stack
                placed = true;
                if (inventory[index].item.amount + inventory[i].item.amount <= inventory[index].item.data.maxItemsPerStack)
                {
                    inventory[i].item.amount += inventory[index].item.amount;
                    inventory[index].TurnOff();
                    break;
                }
                else
                {
                    int t = inventory[i].item.amount;
                    inventory[i].item.amount = inventory[index].item.data.maxItemsPerStack;
                    inventory[index].item.amount -= inventory[i].item.data.maxItemsPerStack - t;
                    MoveItemsToHotBarBase(index, i + 1);
                }
            }
        }
        if (!placed)
        {
            for (int i = 31; i < inventory.Length; i++)
            {
                if (inventory[i].Empty)
                {
                    inventory[i].item = inventory[index].item;
                    inventory[i].TurnOn();
                    inventory[index].TurnOff();
                    break;
                }
            }
        }
    }

    public virtual void PlaceItemInSlot(int index)
    {
        if (!enabled)
            return;
        Debug.Log(index + ": " + itemInHand.slotType + " " + inventory[index].slotType);
        if (Statics.CompareSlotTypes(itemInHand.slotType,inventory[index].slotType))
        {
            inventory[index].item = itemInHand.item; // change the item in the inventory slot in memory
            itemInHand.TurnOff();
            inventory[index].TurnOn();
        }
    }

    public virtual void SwapStacks(int index) // when I have 1 type of item and click on another
    {
        if (!enabled)
            return;
        Debug.Log(index + ": " + itemInHand.slotType + " " + inventory[index].slotType);
        if (Statics.CompareSlotTypes(itemInHand.slotType,inventory[index].slotType))
        {
            Item temp = itemInHand.item; // temp for swapping
            itemInHand.slotType = inventory[index].item.slotType;
            itemInHand.item = inventory[index].item; // change the item in my hand in memory
            inventory[index].item = temp; // change the item in the inv in memory
            inventory[index].image.sprite = inventory[index].item.sprite;
            inventory[index].image.color = max;
            itemInHand.image.sprite = itemInHand.item.sprite; // set the sprite of the thing in my hand
        }
    }

    public virtual void CombineStacks(int index)
    {
        if (!enabled)
            return;
        //TODO: check for item count
        if (itemInHand.item.amount + inventory[index].item.amount <= itemInHand.item.data.maxItemsPerStack)
        { //Check whether my item in hand amount + the item amount in the itemSlot is less than the maxItemsPerStack of that item
            // Yes it is
            inventory[index].item.amount += itemInHand.item.amount; // combine the amount of items
            itemInHand.TurnOff();
            inventory[index].TurnOn();
        }
        else
        {
            // Nope overflow
            itemInHand.item.amount = inventory[index].item.amount + itemInHand.item.amount - itemInHand.item.data.maxItemsPerStack; // set the amount of items in my hand to the overflow after combining the stacks
            inventory[index].item.amount = itemInHand.item.data.maxItemsPerStack; // combine the amount of items
        }
    }

    public virtual void GrabFullStack(int index)
    {
        if (!enabled)
            return;
        if (inventory[index].Empty) // if item in the slot is air
            return;
        itemInHand.item = inventory[index].item; // put the item in my hand
        itemInHand.image.sprite = inventory[index].item.sprite; // change the sprite of the item in my hand
        itemInHand.slotType = inventory[index].item.slotType; // change the slotType of the item in my hand
        itemInHand.TurnOn(); 
        inventory[index].TurnOff();
        info.SetActive(false); // Disable info when grabbing items
        Debug.Log("I just grabbed a full stack");
    }

    public virtual void CheckInput()
    {
        if (!enabled)
            return;
        int s = Statics.CheckInput();
        if (s != -1 && currentHover != -1)
        {
            update = true;
            if (!inventory[currentHover].Empty)
            {
                if (!inventory[currentHover].item.data.Equals(inventory[Statics.HotToSlot(s, 4)].item.data))
                {
                    GrabFullStack(currentHover);
                    SwapStacks(Statics.HotToSlot(s, 4));
                    PlaceItemInSlot(currentHover);
                }
                else
                {
                    GrabFullStack(currentHover);
                    CombineStacks(Statics.HotToSlot(s, 4));
                    if (!itemInHand.Empty)
                    {
                        PlaceItemInSlot(currentHover);
                    }
                }
                if (inventory[currentHover].Empty)
                {
                    inventory[currentHover].TurnOff();
                }
                inventory[Statics.HotToSlot(s, 4)].TurnOn();
            }
            else
            {
                if (!inventory[Statics.HotToSlot(s, 4)].item.data.Equals(inventory[currentHover].item.data))
                {
                    GrabFullStack(Statics.HotToSlot(s, 4));
                    SwapStacks(currentHover);
                    PlaceItemInSlot(Statics.HotToSlot(s, 4));
                }
                else
                {
                    if (!inventory[Statics.HotToSlot(s, 4)].item.Empty)
                    {
                        GrabFullStack(Statics.HotToSlot(s, 4));
                        CombineStacks(currentHover);
                        if (!itemInHand.Empty)
                        {
                            PlaceItemInSlot(Statics.HotToSlot(s, 4));
                        }
                    }
                }
            }
            if(inventory[Statics.HotToSlot(s, 4)].Empty)
                inventory[Statics.HotToSlot(s, 4)].TurnOff();
            else
                inventory[Statics.HotToSlot(s, 4)].TurnOn();
            if (inventory[currentHover].Empty)
                inventory[currentHover].TurnOff();
            else
                inventory[currentHover].TurnOn();
        }
    }

    public void Update()
    {
        if (!enabled)
            return;
        if (!inventoryUI.activeSelf)
            return;
        CheckInput();
        if (itemInHand.image.enabled)
        {
            itemInHand.image.transform.position = Input.mousePosition;
        }
        if (info.activeSelf)
        {
            info.transform.position = Input.mousePosition;
        }
        if (update)
        {
            for (int i = 0; i < inventory.Length; i++)
            {
                inventory[i].text.text = inventory[i].item.amount.ToString();
            }
            itemInHand.text.text = itemInHand.item.amount.ToString();
            update = false;
        }
    }
}