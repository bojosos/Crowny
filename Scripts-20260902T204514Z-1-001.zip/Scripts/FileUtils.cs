﻿using UnityEngine;
using System.IO;

public static class FileUtils
{

    public static void SavePlayerInventory(Inventory playerInv, string fileName)
    {
        fileName += ".nrbin";
        string res = "";
        if (!File.Exists(fileName))
            File.Create(fileName);
        foreach (Slot s in playerInv.inventory)
        {
            res += s.id.ToString() + " " + s.item.amount.ToString() + ";";
        }
        StreamWriter sr = File.CreateText(fileName);
        sr.WriteLine(res);
        sr.Close();
    }

    public static void SaveChestInventory(ChestInventory chestInv)
    {
        
    }

    public static PlayerInventory LoadPlayerFile(string fileName)
    {
        fileName += ".nrbin";
        string[] lines = File.ReadAllLines(fileName);
        foreach (string line in lines)
        {
            if (line == "")
                continue;
            
        }
        return null;
    }

}