﻿using UnityEngine;
using UnityEngine.UI;
using System;

public class F3 : MonoBehaviour
{

    private double deltaTime = 0;
    private double dt;

    private GameObject panel;
    private Text gameStats;
    private Transform playerPos;
    private Text x,y,z;

    void Start()
    {
        panel = transform.GetChild(0).gameObject;
        gameStats = panel.transform.GetChild(1).GetComponent<Text>();
        gameStats.text = "(" + 0.ToString("N3") + " fps, " + 0.ToString("N3") + " ms)";
        playerPos = panel.transform.GetChild(2);
        x = playerPos.GetChild(1).GetComponent<Text>();
        y = playerPos.GetChild(2).GetComponent<Text>();
        z = playerPos.GetChild(3).GetComponent<Text>();
    }

    void Update()
    {
        if (GameManager.instance.activeInventory)
            return;
        dt += Time.deltaTime;
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        if (dt > 1)
        {
            double msec = deltaTime * 1000.0f;
            double f = 1.0f / deltaTime;
            gameStats.text = "(" + f.ToString("N3") + " fps, " + msec.ToString("N3") + " ms)";
            dt = 0;
        }
        x.text = "x: " + Player.Position.x.ToString("N3");
        y.text = "y: " + Player.Position.y.ToString("N3") + " (eye pos)";
        z.text = "z: " + Player.Position.z.ToString("N3");
        if (Input.GetKeyDown(KeyCode.F3))
        {
            panel.SetActive(!panel.activeSelf);
        }
    }

}