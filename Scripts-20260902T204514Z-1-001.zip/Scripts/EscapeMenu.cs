﻿using UnityEngine;

public class EscapeMenu : MonoBehaviour{

    void Start(){
        
    }

    void OnSavePress(){
        GameManager.instance.SavePlayerItems();    
    }



}