﻿using System.Collections.Generic;
using UnityEngine;
using System.Linq;

class AStarPathfinder
{
    private Block start, end;
    private Queue<Block> path;
    private World world;
    private int pathLength=0;

    public AStarPathfinder(World world,Block start, Block end)
    {
        Debug.Log("Pathfinding from " + start.x + " " + start.y + " " + start.z);
        this.start = start;
        this.end = end;
        this.world = world;
    }

    public void DoWork()
    {

        PathfindingPriorityQueue<Block> openSet = new PathfindingPriorityQueue<Block>(100);
        HashSet<Block> closedSet = new HashSet<Block>();
        Debug.Log("Pathfinding from " + start.x + " " + start.y + " " + start.z);
        openSet.Enqueue(start,0);

        Dictionary<Block, Block> came_from = new Dictionary<Block, Block>();

        Dictionary<Block, int> g_score = new Dictionary<Block, int>();
        Dictionary<Block, int> f_score = new Dictionary<Block, int>();

        while (openSet.Count > 0)
        {
            Block block = openSet.Dequeue();
            Debug.Log(block.x + " " + block.y + " " + block.z);
            if (block.Equals(end))
            {
                RestracePath(came_from, block);
                return;
            }

            closedSet.Add(block);

            foreach(Block neighbour in block.GetNeighbours(world))
            {
                if (closedSet.Contains(neighbour))
                    continue;

                int gCost = GetDistance(start, neighbour);

                if (gCost < 0)
                    continue;

                if (openSet.Contains(neighbour) && gCost >= g_score[neighbour])
                    continue;

                came_from[neighbour] = block;
                g_score[neighbour] = gCost;
                f_score[neighbour] = gCost + GetDistance(neighbour, end);

                openSet.EnqueueOrUpdate(neighbour, f_score[neighbour]);

            }

        }

    }

    private int GetDistance(Block pos1, Block pos2)
    {
        int dstX = Mathf.Abs(pos1.x - pos2.x);
        int dstY = Mathf.Abs(pos1.y - pos2.y);
        int dstZ = Mathf.Abs(pos1.z - pos2.z);

        if (dstX > dstZ)
            return 14 * dstZ + 10 * (dstX - dstZ + dstY);
        return 14 * dstX + 10 * (dstZ - dstX + dstY);
    }

    private void RestracePath(Dictionary<Block, Block> came_from, Block pos)
    {
        Debug.Log("Retracing");
        Queue<Block> total_path = new Queue<Block>();
        total_path.Enqueue(pos);

        while (came_from.ContainsKey(pos))
        {
            pos = came_from[pos];
            total_path.Enqueue(pos);
        }
        path = new Queue<Block>(total_path.Reverse());
    }

    public Block[] GetPath()
    {
        return path.ToArray();
    }

}
