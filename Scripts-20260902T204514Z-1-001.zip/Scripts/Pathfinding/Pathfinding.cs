﻿using UnityEngine;
using System.Linq;

public class Pathfinding : MonoBehaviour{

    private static World world;
    private static Player player;
    private static Entity target;
    public LineRenderer lineRenderer;

    void Start()
    {
        world = FindObjectOfType<World>();

    }

    Block[] path;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            player = GameObject.FindObjectOfType<Player>();
            target = FindObjectOfType<Entity>();
            Block b1 = player.GetBlock();
            Debug.Log("Pathfinding1: Pathfinding from " + b1.x + " " + b1.y + " " + b1.z);
            Block b2 = target.GetBlock();
            Block[] path = FindPath(world, b1, b2);
            this.path = path;
        }
    }

    public static Block[] FindPath(World world,Block start, Block end)
    {

        AStarPathfinder pathfinder = new AStarPathfinder(world, start, end);

        pathfinder.DoWork();

        return pathfinder.GetPath();
    }

    private void OnDrawGizmos()
    {
        if (path != null)
        {
            Debug.Log("Drawing path");
            for (int i = 0; i < path.Length - 1; i++)
            {
                path[i].y = 11;
                path[i + 1].y = 11;
                Gizmos.DrawLine(path[i].ToVector3(), path[i + 1].ToVector3());
            }
        }
    }

}
