﻿using UnityEngine;

public class Statics : MonoBehaviour
{
    public static float GameTime;
    public static Color max = new Color(255, 255, 255, 255);
    public static Color min = new Color(0.01f, 0.01f, 0.01f, 0.01f);

    void Update()
    {
        GameTime += Time.deltaTime;
    }

    public static int CheckInput()
    {
        int res = -1;
        if (Input.GetKeyDown(KeyCode.Alpha1))
            res = 0;
        if (Input.GetKeyDown(KeyCode.Alpha2))
            res = 1;
        if (Input.GetKeyDown(KeyCode.Alpha3))
            res = 2;
        if (Input.GetKeyDown(KeyCode.Alpha4))
            res = 3;
        if (Input.GetKeyDown(KeyCode.Alpha5))
            res = 4;
        if (Input.GetKeyDown(KeyCode.Alpha6))
            res = 5;
        if (Input.GetKeyDown(KeyCode.Alpha7))
            res = 6;
        if (Input.GetKeyDown(KeyCode.Alpha8))
            res = 7;
        if (Input.GetKeyDown(KeyCode.Alpha9))
            res = 8;
        return res;
    }

    public static int HotToSlot(int slot, int offset = 0)
    {
        return slot + 27 + offset;
    }

    // If you want to put s1 into s2
    public static bool CompareSlotTypes(SlotType s1,SlotType s2)
    {
        if (s2 == SlotType.Anything)
            return true;
        if (s1 == s2)
            return true;
        return false;
    }
}