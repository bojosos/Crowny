﻿using UnityEngine;

public class Player : MonoBehaviour
{
    Vector2 rot;
    public static Vector3 Position;

    //These should be in Block
    private float timer = 0;
    private float blockBreakTime = 1f;
    private WorldPos pos;

    [SerializeField]
    public GameObject selected;

    public GameObject firstPersonCamera;
    public GameObject thirdPersonCamera;

    private World world;
    public static World World;

    RaycastHit hit;
    Ray ray;

    public LayerMask entityMask;

    public int selection = 0;
    bool changed = true;

    int[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

    Vector3 Abs(Vector3 v)
    {
        if (v.x < 0)
            v.x = -v.x;
        if (v.y < 0)
            v.y = -v.y;
        if (v.z < 0)
            v.z = -v.z;
        return v;
    }

    private void Start()
    {
        world = FindObjectOfType<World>();
        World = world;
    }

    void Update()
    {
        Position = transform.position;
        if (GameManager.instance.activeInventory)
            return;
        if (Input.GetMouseButton(0))
        {
            ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2.0f, Screen.height / 2.0f, 0));
            if (Physics.Raycast(ray, out hit, 100) && hit.collider.tag == "Chunk")
            {
                for (int i = 0; i < 6; i++)
                    UIManager.blockSides[i].enabled = true;
                WorldPos p = Terrain.GetBlockPos(hit);
                if (p.Equals(pos))
                {
                    timer += Time.deltaTime;
                    if (timer > blockBreakTime)
                    {
                        timer = 0;
                        Terrain.SetBlock(hit, new BlockAir(p.x,p.y,p.z));
                        for (int i = 0; i < 6; i++)
                        {
                            UIManager.blockSides[i].enabled = false;
                        }
                    }
                    for (int i = 0; i <= 9; i++)
                    {
                        if (timer >= 0.1f * i)
                        {
                            Terrain.GetBlock(hit).DoBlockStages(hit, i);
                        }
                    }
                }
                else
                {
                    timer = 0;
                    pos = p;
                    for (int i = 0; i < 6; i++)
                    {
                        UIManager.blockSides[i].enabled = false;
                    }
                }
            }
        }

        if (Input.GetMouseButtonUp(0))
        {
            for (int i = 0; i < 6; i++)
            {
                UIManager.blockSides[i].color = new Color(255, 255, 255, 255);
                UIManager.blockSides[i].enabled = false;
            }
            timer = 0;
        }

        // Fix this
        if (Input.GetKeyDown(KeyCode.F5))
        {
            firstPersonCamera.SetActive(!firstPersonCamera.activeSelf);
            thirdPersonCamera.SetActive(!thirdPersonCamera.activeSelf);
        }

        if (Input.GetMouseButtonDown(1))
        {
            ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
            if (Physics.Raycast(ray, out hit, 100) && hit.transform.CompareTag("Chunk"))
            {
                Block block = Terrain.GetBlock(hit, true);
                WorldPos blockPos = Terrain.GetBlockPos(hit, true);

                if (blockPos.x != block.x || blockPos.y != block.y || blockPos.z != block.z)
                {
                    Debug.Log("This is bad: " + block.x + " " + block.y + " " + block.z);
                    Debug.Log("This is bad: " + blockPos.x + " " + blockPos.y + " " + blockPos.z);
                }

                bool up = false;
                if (hit.point.y > blockPos.y)
                    up = true;
                Block newBlock = GameManager.instance.GetHotbarBlock(blockPos.x, blockPos.y, blockPos.z, selection, up);
                if (Physics.CheckBox(new Vector3(blockPos.x, blockPos.y, blockPos.z),new Vector3 (0.49f, 0.49f, 0.49f),Quaternion.identity,entityMask))
                     return;
                if (newBlock == null)
                    return;
                bool half = block is HalfBlock;
                if (newBlock is HalfBlock && half)
                {
                    Terrain.SetBlock(hit, new BlockAir(blockPos.x, blockPos.y, blockPos.z), true);
                    Terrain.SetBlock(hit, new BlockStone(blockPos.x, blockPos.y, blockPos.z), true);
                }
                else
                    Terrain.SetBlock(hit, newBlock, true, half, !up);
            }
        }

        ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
        if (Physics.Raycast(ray, out hit, 100) && hit.transform.CompareTag("Chunk"))
        {
            Block block = Terrain.GetBlock(hit);
            block.DoHighlight(hit);
            block.ShowNeighbourCount();
        }

        CheckInput();
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            int mov = (int)(scroll / 0.1f) * -1;
            selection = a[selection + 9 + mov] - 1;
            GameManager.selected = selection;
            selected.transform.position = UIManager.ingameSlots[selection].transform.position;
        }

    }

    public Block GetBlock()
    {
        int x = (int)Mathf.Floor(transform.position.x);
        int y = (int)Mathf.Floor(transform.position.y);
        int z = (int)Mathf.Floor(transform.position.z);
        return world.GetBlock(x, y-1, z);
    }

    void CheckInput()
    {
        int s = Statics.CheckInput();
        if (s != -1)
        {
            selection = s;
            GameManager.selected = s;
            changed = true;
        }

        if (changed)
        {
            selected.transform.position = UIManager.ingameSlots[selection].transform.position;
            changed = false;
        }
    }
}