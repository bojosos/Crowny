﻿using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshCollider))]

public class Chunk : MonoBehaviour
{

    public Block[,,] blocks = new Block[chunkSize, chunkHeight, chunkSize];

    public static int chunkSize = 16;
    public static int chunkHeight = 256;
    public bool update = false;
    public bool rendered;

    MeshFilter filter;
    MeshCollider coll;


    public World world;
    public WorldPos pos;

    void Start()
    {
        filter = GetComponent<MeshFilter>();
        coll = GetComponent<MeshCollider>();
    }

    void Update()
    {
        if (update)
        {
            update = false;
            RenderChunk();
        }
        if (update)
        {
            update = false;
            UpdateChunk();
        }
    }

    void UpdateChunk()
    {
    }

    public static void SetBlock(Block block, Chunk chunk, bool replaceBlocks = false)
    {
        if (Chunk.InRange(block.x - chunk.pos.x) && Chunk.InRange(block.y - chunk.pos.y, true) && Chunk.InRange(block.z - chunk.pos.z))
        {
            if (replaceBlocks || chunk.blocks[block.x - chunk.pos.x, block.y - chunk.pos.y, block.z - chunk.pos.z] == null)
                chunk.SetBlock(block);
        }
    }

    public Block GetBlock(int x, int y, int z)
    {
        if (InRange(x - pos.x) && InRange(y - pos.y, true) && InRange(z - pos.z))
        {
            return blocks[x - pos.x, y - pos.y, z - pos.z];
        }
        return world.GetBlock(x, y, z);
    }

    public static bool InRange(int index, bool y = false)
    {
        if (!y)
        if (index < 0 || index >= chunkSize)
            return false;
        if (index < 0 || index >= chunkHeight)
            return false;
        return true;
    }

    public void SetBlock(Block block)
    {
        if (InRange(block.x-pos.x) && InRange(block.y - pos.y, true) && InRange(block.z - pos.z))
        {
            blocks[block.x-pos.x,block.y-pos.y,block.z-pos.z] = block;
        }
        else
        {
            world.SetBlock(block);
        }
    }

    public void SetBlocksUnmodified()
    {
        foreach (Block block in blocks)
        {
            block.changed = false;
        }
    }

    void RenderChunk()
    {
        rendered = true;
        MeshData meshData = new MeshData();
        for (int x = 0; x < chunkSize; x++)
        {
            for (int y = 0; y < chunkHeight; y++)
            {
                for (int z = 0; z < chunkSize; z++)
                {
                    meshData = blocks[x, y, z].Blockdata(this, meshData);
                }
            }
        }

        RenderMesh(meshData);
    }

    void RenderMesh(MeshData meshData)
    {
        filter.mesh.Clear();
        filter.mesh.vertices = meshData.vertices.ToArray();
        filter.mesh.triangles = meshData.triangles.ToArray();

        filter.mesh.uv = meshData.uv.ToArray();
        filter.mesh.RecalculateNormals();

        coll.sharedMesh = null;
        Mesh mesh = new Mesh();
        mesh.vertices = meshData.colVertices.ToArray();
        mesh.triangles = meshData.colTriangles.ToArray();
        mesh.RecalculateNormals();

        coll.sharedMesh = mesh;
    }

}