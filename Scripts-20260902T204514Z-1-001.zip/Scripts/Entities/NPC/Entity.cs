﻿using UnityEngine;

public class Entity : MonoBehaviour {

    public World world;

    private void Start()
    {
        world = FindObjectOfType<World>();
    }

    public Block GetBlock()
    {
        int x = (int)Mathf.Floor(transform.position.x);
        int y = (int)Mathf.Floor(transform.position.y);
        int z = (int)Mathf.Floor(transform.position.z);
        Debug.Log(x + " " + y + " " + z);
        Debug.Log("Entity: X Y Z" + world.GetBlock(x, y, z));
        Debug.Log("Entity: X Y-1 Z" + world.GetBlock(x, y - 1, z));
        return world.GetBlock(x, y-1, z);
    }
   
}
