﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

public class Button2 : MonoBehaviour, IPointerDownHandler, IPointerExitHandler, IPointerEnterHandler
{
    public delegate void RightClickAction();

    public delegate void LeftClickAction();

    public delegate void HoverChangeAction();

    public delegate void HoverExitAction();

    public delegate void ShiftPressAction();

    public event RightClickAction OnRightClick;
    public event LeftClickAction OnLeftClick;
    public event HoverChangeAction OnHoverChange;
    public event HoverExitAction OnHoverExit;
    public event ShiftPressAction OnShiftPress;



    public void OnPointerDown(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Right)
        {
            if (OnRightClick != null)
                OnRightClick();
        }
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            if (Input.GetKey(KeyCode.LeftShift))
            {
                if (OnShiftPress != null)
                    OnShiftPress();
                return;
            }
            if (OnLeftClick != null)
                OnLeftClick();
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (eventData.pointerCurrentRaycast.gameObject.name == this.gameObject.name)
        {
            if (OnHoverChange != null)
                OnHoverChange();
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (OnHoverExit != null)
            OnHoverExit();
    }

    public void AddRightClickListener(RightClickAction a)
    {
        OnRightClick += a;
    }

    public void AddLeftClickListener(LeftClickAction a)
    {
        OnLeftClick += a;
    }

    public void AddHoverChangeListener(HoverChangeAction a)
    {
        OnHoverChange += a;
    }

    public void AddHoverExitListener(HoverExitAction a)
    {
        OnHoverExit += a;
    }

    public void AddShiftPressListener(ShiftPressAction a)
    {
        OnShiftPress += a;
    }

}