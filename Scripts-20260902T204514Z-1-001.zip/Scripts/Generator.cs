﻿using UnityEngine;

public class Generator
{

    float stoneBaseHeight = -24;
    float stoneBaseNoise = 0.05f;
    float stoneBaseNoiseHeight = 4;
    float stoneMountainHeight = 20;
    float stoneMountainFrequency = 0.08f;
    float stoneMinHeight = -12;
    float dirtBaseHeight = 20;
    float dirtNoise = 0.04f;
    float dirtNoiseHeight = 3;
    float caveFrequency = 0.25f;
    float caveSize = 7f;

    public Chunk ChunkGen(Chunk chunk)
    {
        Debug.Log(chunk.pos.x + " " + chunk.pos.z);
        for (int x = chunk.pos.x; x < chunk.pos.x + Chunk.chunkSize; x++)
        {
            for (int z = chunk.pos.z; z < chunk.pos.z + Chunk.chunkSize; z++)
            {
                chunk = ChunkColumnGen(chunk, x, z);
            }
        }
        return chunk;
    }

    public Chunk ChunkColumnGen(Chunk chunk, int x, int z)
    {
        int stoneHeight = Mathf.FloorToInt(stoneBaseHeight);
        stoneHeight += GetNoise(x, 0, z, stoneMountainFrequency, Mathf.FloorToInt(stoneMountainHeight));
        if (stoneHeight < stoneMinHeight)
            stoneHeight = Mathf.FloorToInt(stoneMinHeight);
        stoneHeight += GetNoise(x, 0, z, stoneBaseNoise, Mathf.FloorToInt(stoneBaseNoiseHeight));
        int dirtHeight = stoneHeight + Mathf.FloorToInt(dirtBaseHeight);
        dirtHeight += GetNoise(x, 100, z, dirtNoise, Mathf.FloorToInt(dirtNoiseHeight));
        for (int y = chunk.pos.y; y < chunk.pos.y + Chunk.chunkHeight; y++)
        {
            //   int caveChance = GetNoise(x, y, z, caveFrequency, 100);
            if (y <= stoneHeight)// && caveSize < caveChance)
            {
                Block b = new BlockStone(x, y, z);
                chunk.SetBlock(b);
            }
            else if (y <= dirtHeight)// && caveSize < caveChance)
            {
                Block b = new BlockGrass(x, y, z);
                chunk.SetBlock(b);
            }
            else
            {
                Block b = new BlockAir(x, y, z);
                chunk.SetBlock(b);
            }
        }
        return chunk;
    }

    public static int GetNoise(int x, int y, int z, float scale, int max)
    {
        return 1;
        //return (int)(Mathf.PerlinNoise((x/* + seed*/) * scale, (z/* + seed*/) * scale) * max);
    }
}
