﻿using System;

[Serializable]
public class BlockAir : Block
{
    public BlockAir(int x,int y,int z) : base()
    {
        this.x = x;
        this.y = y;
        this.z = z;
        canWalk = false;
        canJump = false;
    }

    public override MeshData Blockdata(Chunk chunk, MeshData meshData)
    {
        return meshData;
    }

    public override bool IsSolid(Direction direction)
    {
        return false;
    }
}