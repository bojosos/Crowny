﻿using UnityEngine;

public struct ItemType
{
    public int maxItemsPerStack;
    public int id;
    public TypeBlock blockType;
    public TypeItem itemType;
    //public ArmorType armorType;

    public override bool Equals(object obj)
    {
        if (!(obj is ItemType))
            return false;

        ItemType pos = (ItemType)obj;
        if (pos.id != id)
            return false;
        return true;
    }
}


public enum TypeBlock
{
    Unknown,
    BlockAir,
    BlockDirt,
    BlockGrass,
    BlockCobblestone,
    CobblestoneSlab,
    BlockStoneBrick,
    Other}

;

public enum Direction
{
    east,
    north,
    south,
    west,
    up,
    down}
;

public struct Tile
{
    public int x, y;
}

public enum ArmorType
{
    Helmet,
    Chestplate,
    Pants,
    Boots}
;

public enum SlotType
{
    Anything,
    Result,
    Boots,
    Pants,
    Helmet,
    Chestplate}
;

public enum TypeItem
{
    Armor,
    Tool,
    Block}
;

public struct Slot
{
    public UnityEngine.UI.Image image;
    public SlotType slotType;
    public Item item;
    public UnityEngine.UI.Text text;

    public bool Empty
    {
        get
        {
            return item.Empty;
        }
    }

    public void TurnOn(){
        image.color = Statics.max;
        text.enabled = true;
        image.sprite = item.sprite;
        text.enabled = true;
    }

    public void TurnOff(){
        item.SetToNull();
        image.sprite = null;
        image.color = Statics.min;
        text.enabled = false;
    }

    public int id{
        get{
            return item.data.id;
        }
    }

}