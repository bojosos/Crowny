﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public static class ItemList
{
    public static Item BlockAir;
    public static Item BlockGrass;
    public static Item BlockCobblestone;
    public static Item BlockStonebrick;
    public static Item BlockHalfSlab;
    public static Item BlockDirt;

    public static Item DiamondHelmet;
    public static Item DiamondChestplate;
    public static Item DiamondPants;
    public static Item DiamondBoots;

    private static Sprite[] sprite;

    private static List<Item> items = new List<Item>();

    public static void Start(Sprite[] sprites)
    {
        sprite = sprites;
        BlockAir = new Item(null, 0, TypeBlock.BlockAir, 0, "Air", TypeItem.Block);
        BlockDirt = new Item(sprite[1], 1, TypeBlock.BlockDirt, 1, "Dirt", TypeItem.Block);
        BlockGrass = new Item(sprite[2], 1, TypeBlock.BlockGrass, 2, "Grass", TypeItem.Block);
        BlockCobblestone = new Item(sprite[3], 1, TypeBlock.BlockCobblestone, 3, "Cobblestone", TypeItem.Block);
        BlockStonebrick = new Item(sprite[4], 1, TypeBlock.BlockStoneBrick, 4, "Stonebrick", TypeItem.Block);
        BlockHalfSlab = new Item(sprite[5], 1, TypeBlock.CobblestoneSlab, 5, "Cobblestone slab", TypeItem.Block);
        DiamondHelmet = new Item(sprite[6], 1, TypeBlock.Other, 6, "Diamond Helmet", TypeItem.Armor, 1, SlotType.Helmet);
        DiamondChestplate = new Item(sprite[7], 1, TypeBlock.Other, 7, "Diamond Chestplate", TypeItem.Armor, 1, SlotType.Chestplate);
        DiamondPants = new Item(sprite[8], 1, TypeBlock.Other, 8, "Diamond Pants", TypeItem.Armor, 1, SlotType.Pants);
        DiamondBoots = new Item(sprite[9], 1, TypeBlock.Other, 9, "Diamond Boots", TypeItem.Armor, 1, SlotType.Boots);
        items.Add(BlockAir);
        items.Add(BlockDirt);
        items.Add(BlockGrass);
        items.Add(BlockCobblestone);
        items.Add(BlockStonebrick);
        items.Add(BlockHalfSlab);
        items.Add(DiamondHelmet);
        items.Add(DiamondChestplate);
        items.Add(DiamondPants);
        items.Add(DiamondBoots);
    }

    public static Item GetItemById(int id)
    {
        if (id < items.Count)
            return items.Where(p => p.id == id).First();
        return BlockAir;
    }

}