﻿using System;

[Serializable]
public class BlockLeaves : Block {

    public BlockLeaves(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public override Tile TexturePosition(Direction direction)
    {
        Tile tile = new Tile();
        tile.x = 0;
        tile.y = 1;
        return tile;
    }

    public override bool IsSolid(Direction direction)
    {
        return false;
    }

}
