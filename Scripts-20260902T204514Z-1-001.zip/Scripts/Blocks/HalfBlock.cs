﻿using UnityEngine;
using System;

[Serializable]
public class HalfBlock : Block
{
    public int up;

    public HalfBlock(int x,int y,int z,bool up)
        : base()
    {
        this.x = x;
        this.y = y;
        this.z = z;
        if (up)
            this.up = 1;
        else
            this.up = 0;
    }

    public override Tile TexturePosition(Direction direction)
    {
        Tile tile = new Tile();
        tile.x = 0;
        tile.y = 0;
        return tile;
    }

    public override void DoBlockStages(RaycastHit hit, int i)
    {
        for (int j = 0; j < 6; j++)
            UIManager.blockSides[j].sprite = UIManager.stages[i];
        Vector3 asd = new Vector3();
        WorldPos pos = Terrain.GetBlockPos(hit);
        asd.x = pos.x;
        asd.y = pos.y;
        asd.z = pos.z;
        asd.y = pos.y + 0.51f * up;
        UIManager.blockSides[0].transform.position = asd;
        asd.y = pos.y;
        asd.y = pos.y - 0.51f * (up - 1);
        UIManager.blockSides[1].transform.position = asd;
        asd.y = pos.y;
        asd.z = pos.z + 0.51f;
        UIManager.blockSides[2].transform.position = asd;
        asd.z = pos.z;
        asd.z = pos.z - 0.51f;
        UIManager.blockSides[3].transform.position = asd;
        asd.z = pos.z;
        asd.x = pos.x + 0.51f;
        UIManager.blockSides[4].transform.position = asd;
        asd.x = pos.x - 0.51f;
        UIManager.blockSides[5].transform.position = asd;
    }

    public override Vector2[] FaceUVs(Direction direction)
    {
        Vector2[] UVs = new Vector2[4];
        Tile tilePos = TexturePosition(direction);
        if (direction == Direction.down || direction == Direction.up)
        {
            UVs[0] = new Vector2(0.25f * tilePos.x + 0.25f,
                0.25f * tilePos.y);
            UVs[1] = new Vector2(0.25f * tilePos.x + 0.25f,
                0.25f * tilePos.y + 0.25f);
            UVs[2] = new Vector2(0.25f * tilePos.x,
                0.25f * tilePos.y + 0.25f);
            UVs[3] = new Vector2(0.25f * tilePos.x,
                0.25f * tilePos.y);
            return UVs;
        }
        UVs[0] = new Vector2(0.25f * tilePos.x + 0.25f,
            0.125f * tilePos.y);
        UVs[1] = new Vector2(0.25f * tilePos.x + 0.25f,
            0.125f * tilePos.y + 0.125f);
        UVs[2] = new Vector2(0.25f * tilePos.x,
            0.125f * tilePos.y + 0.125f);
        UVs[3] = new Vector2(0.25f * tilePos.x,
            0.125f * tilePos.y);
        return UVs;
    }

    public override MeshData FaceDataNorth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z + 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.north));
        return meshData;
    }

    public override MeshData FaceDataEast
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z + 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.east));
        return meshData;
    }

    public override MeshData FaceDataSouth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z - 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.south));
        return meshData;
    }

    public override MeshData FaceDataWest
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z - 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.west));
        return meshData;
    }


    public override MeshData FaceDataUp
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + up * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + up * 0.5f, z - 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.up));
        return meshData;
    }

    public override MeshData FaceDataDown
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + (up - 1) * 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + (up - 1) * 0.5f, z + 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.down));
        return meshData;
    }

}