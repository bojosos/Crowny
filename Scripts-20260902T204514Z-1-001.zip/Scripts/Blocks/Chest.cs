﻿using UnityEngine;
using System;

[Serializable]
public class Chest : Block
{

    public Chest(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public override Tile TexturePosition(Direction direction)
    {
        Tile tile = new Tile();
        tile.x = 3;
        tile.y = 1;
        switch (direction)
        {
            case Direction.west:
                tile.y = 3;
                return tile;
            case Direction.up:
                tile.y = 2;
                return tile;
            case Direction.down:
                tile.y = 2;
                return tile;
        }
        return tile;
    }

    public override MeshData FaceDataUp
         (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z - 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z - 0.45f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.up));
        return meshData;
    }

    public override MeshData FaceDataDown
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.down));
        return meshData;
    }

    public override MeshData FaceDataNorth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.north));
        return meshData;
    }

    public override MeshData FaceDataEast
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.east));
        return meshData;
    }

    public override MeshData FaceDataSouth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y + 0.45f, z - 0.45f));
        meshData.AddVertex(new Vector3(x + 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.south));
        return meshData;
    }

    public override MeshData FaceDataWest(Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z + 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z + 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y + 0.45f, z - 0.45f));
        meshData.AddVertex(new Vector3(x - 0.45f, y - 0.5f, z - 0.45f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.west));
        return meshData;
    }

    public override bool IsSolid(Direction direction)
    {
        return false;
    }

}