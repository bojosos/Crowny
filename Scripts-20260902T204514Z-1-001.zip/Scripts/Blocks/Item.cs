﻿using UnityEngine;

public struct Item
{

    public Sprite sprite;
    public int amount;
    public ItemType data;
    public string name;
    public string description;
    public SlotType slotType;

    public int id
    {
        get
        {
            return data.id;
        }
    }

    public Item(Sprite sprite, int amount, TypeBlock type, int id, string name, TypeItem it, int max = 64, SlotType st = SlotType.Anything)
    {
        this.sprite = sprite;
        this.amount = amount;

        this.data.blockType = type;
        this.data.itemType = it;
        this.data.id = id;
        this.data.maxItemsPerStack = max;

        this.name = name;
        this.description = "test";

        this.slotType = st;
    }

    public Item(int id, int amount)
    {
        Item tmp = ItemList.GetItemById(id);
        data = tmp.data;
        sprite = tmp.sprite;
        name = tmp.name;
        description = tmp.description;
        slotType = tmp.slotType;
        this.amount = 0;
        if (!tmp.Equals(ItemList.BlockAir))
            this.amount = amount;
    }

    public void SetToNull()
    {
        this = ItemList.BlockAir;
    }

    public bool Empty
    {
        get
        {
            return this.data.Equals(ItemList.BlockAir.data);
        }
    }

    public bool IsArmor()
    {
        return (slotType == SlotType.Helmet || slotType == SlotType.Chestplate || slotType == SlotType.Pants || slotType == SlotType.Boots);
    }
}