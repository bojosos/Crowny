﻿using UnityEngine;
using System;
using System.Collections.Generic;

[Serializable]
public class Block
{

    public bool changed;
    public bool canWalk, canJump;

    public int x,y,z;

    [NonSerialized]
    Block[] neighbours;

    public virtual void Update(Chunk chunk, WorldPos pos)
    {

    }

    public Block(int x,int y,int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void ShowNeighbourCount()
    {
        Vector3 pos = ToVector3();
        pos.y += 0.51f;
        UIManager.InfoText.transform.position = pos;
        if (neighbours == null)
            GetNeighbours(Player.World);
        UIManager.InfoText.text = neighbours.Length.ToString();
    }

    public Block()
    {

    }

    public virtual MeshData Blockdata(Chunk chunk, MeshData meshData)
	{
        if (chunk.GetBlock(x, y + 1, z) is BlockAir && chunk.GetBlock(x, y + 2, z) is BlockAir)
        {
            canWalk = true;
            if (chunk.GetBlock(x, y + 3, z) is BlockAir)
                canJump = true;
        }

		meshData.useRenderDataForCol = true;

		if ((!chunk.GetBlock (x, y + 1, z).IsSolid (Direction.down) || chunk.GetBlock (x, y + 1, z) is HalfBlock || this is HalfBlock || this is Chest) || ((Mathf.Abs (z) % 16 == 0 || Mathf.Abs (x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up)) {
			meshData = FaceDataUp (chunk, x, y, z, meshData);
		}

		if ((!chunk.GetBlock (x, y - 1, z).IsSolid (Direction.up) || chunk.GetBlock (x, y - 1, z) is HalfBlock || this is HalfBlock || this is Chest) || ((Mathf.Abs(z) % 16 == 0 || Mathf.Abs(x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up))
        {
            meshData = FaceDataDown (chunk, x, y, z, meshData);
		}

		if ((!chunk.GetBlock (x, y, z + 1).IsSolid (Direction.south) || chunk.GetBlock (x, y, z + 1) is HalfBlock || this is Chest) || ((Mathf.Abs(z) % 16 == 0 || Mathf.Abs(x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up))
        {
            meshData = FaceDataNorth (chunk, x, y, z, meshData);
		}

		if ((!chunk.GetBlock (x, y, z - 1).IsSolid (Direction.north) || chunk.GetBlock (x, y, z - 1) is HalfBlock || this is Chest) || ((Mathf.Abs(z) % 16 == 0 || Mathf.Abs(x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up))
        {
            meshData = FaceDataSouth (chunk, x, y, z, meshData);
		}

		if ((!chunk.GetBlock (x + 1, y, z).IsSolid (Direction.west) || chunk.GetBlock (x + 1, y, z) is HalfBlock || this is Chest) || ((Mathf.Abs(z) % 16 == 0 || Mathf.Abs(x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up))
        {
            meshData = FaceDataEast (chunk, x, y, z, meshData);
		}

		if ((!chunk.GetBlock (x - 1, y, z).IsSolid (Direction.east) || chunk.GetBlock (x - 1, y, z) is HalfBlock || this is Chest) || ((Mathf.Abs(z) % 16 == 0 || Mathf.Abs(x) % 16 == 0)) && !chunk.GetBlock(x, y + 1, z).IsSolid(Direction.up))
        {
            meshData = FaceDataWest (chunk, x, y, z, meshData);
		}

		return meshData;

	}

    public virtual Block[] GetNeighbours(World world)
    {
        if (neighbours == null)
        {
            List<Block> tmp = new List<Block>();
            for (int x = -1; x <= 1; x++)
            {
                for (int y = -1; y <= 1; y++)
                {
                    for (int z = -1; z <= 1; z++)
                    {
                        if (x != y && x != z && z != y && !(world.GetBlock(this.x+x,this.y+y,this.z+z) is BlockAir))
                            if (y == 0)
                            {
                                Block b = world.GetBlock(this.x + x, this.y + y, this.z + z);
                                if (b.canWalk)
                                    tmp.Add(b);
                            }
                        if (y == 1)
                            if (canJump)
                                tmp.Add(world.GetBlock(this.x + x, this.y + y, this.z + z));
                        if (y == -1)
                        {
                            Block b = world.GetBlock(this.x + x, this.y + y, this.z + z);
                            if (b.canJump)
                                tmp.Add(b);
                        }
                    }
                }
            }
            neighbours = tmp.ToArray();
        }
        return neighbours;
    }

    public Vector3 ToVector3()
    {
        return new Vector3(x,y,z);
    }

    public virtual void DoBlockStages(RaycastHit hit, int i)
    {
        for (int j = 0; j < 6; j++)
            UIManager.blockSides[j].sprite = UIManager.stages[i];

        Vector3 asd = new Vector3();
        WorldPos pos = Terrain.GetBlockPos(hit);
        asd.x = pos.x;
        asd.y = pos.y;
        asd.z = pos.z;
        asd.y = pos.y + 0.51f;
        UIManager.blockSides[0].transform.position = asd;
        asd.y = pos.y;
        asd.y = pos.y - 0.51f;
        UIManager.blockSides[1].transform.position = asd;
        asd.y = pos.y;
        asd.z = pos.z + 0.51f;
        UIManager.blockSides[2].transform.position = asd;
        asd.z = pos.z;
        asd.z = pos.z - 0.51f;
        UIManager.blockSides[3].transform.position = asd;
        asd.z = pos.z;
        asd.x = pos.x + 0.51f;
        UIManager.blockSides[4].transform.position = asd;
        asd.x = pos.x - 0.51f;
        UIManager.blockSides[5].transform.position = asd;
    }

    public virtual void DoHighlight(RaycastHit hit)
    {
        Vector3 asd = new Vector3();
        WorldPos pos = Terrain.GetBlockPos(hit);
        asd.x = pos.x;
        asd.y = pos.y;
        asd.z = pos.z;
        asd.y = pos.y + 0.501f;
        UIManager.highlights[0].transform.position = asd;
        asd.y = pos.y;
        asd.y = pos.y - 0.501f;
        UIManager.highlights[1].transform.position = asd;
        asd.y = pos.y;
        asd.z = pos.z + 0.501f;
        UIManager.highlights[2].transform.position = asd;
        asd.z = pos.z;
        asd.z = pos.z - 0.501f;
        UIManager.highlights[3].transform.position = asd;
        asd.z = pos.z;
        asd.x = pos.x + 0.501f;
        UIManager.highlights[4].transform.position = asd;
        asd.x = pos.x - 0.501f;
        UIManager.highlights[5].transform.position = asd;
    }

    public virtual MeshData FaceDataUp
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));

        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.up));
        return meshData;
    }

    public virtual MeshData FaceDataDown
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.down));
        return meshData;
    }

    public virtual MeshData FaceDataNorth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.north));
        return meshData;
    }

    public virtual MeshData FaceDataEast
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.east));
        return meshData;
    }

    public virtual MeshData FaceDataSouth
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.south));
        return meshData;
    }

    public virtual MeshData FaceDataWest
        (Chunk chunk, int x, int y, int z, MeshData meshData)
    {
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
        meshData.AddVertex(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
        meshData.AddQuadTriangles();
        meshData.uv.AddRange(FaceUVs(Direction.west));
        return meshData;
    }

    public virtual Tile TexturePosition(Direction direction)
    {
        Tile tile = new Tile();
        tile.x = 0;
        tile.y = 0;
        return tile;
    }

    public virtual Vector2[] FaceUVs(Direction direction)
    {
        Vector2[] UVs = new Vector2[4];
        Tile tilePos = TexturePosition(direction);
        UVs[0] = new Vector2(0.25f * tilePos.x + 0.25f,
            0.25f * tilePos.y);
        UVs[1] = new Vector2(0.25f * tilePos.x + 0.25f,
            0.25f * tilePos.y + 0.25f);
        UVs[2] = new Vector2(0.25f * tilePos.x,
            0.25f * tilePos.y + 0.25f);
        UVs[3] = new Vector2(0.25f * tilePos.x,
            0.25f * tilePos.y);

        return UVs;
    }

    public virtual bool IsSolid(Direction direction)
    {
        switch (direction)
        {
            case Direction.north:
                return true;
            case Direction.east:
                return true;
            case Direction.south:
                return true;
            case Direction.west:
                return true;
            case Direction.up:
                return true;
            case Direction.down:
                return true;
        }

        return false;
    }
}