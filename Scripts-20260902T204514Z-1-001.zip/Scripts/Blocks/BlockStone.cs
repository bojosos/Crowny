﻿using System;

[Serializable]
public class BlockStone : Block
{

    public BlockStone(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public override Tile TexturePosition (Direction direction)
	{
		Tile tile = new Tile ();
		tile.x = 0;
		tile.y = 0;
		return tile;
	}
}
