﻿using UnityEngine;
using System;

[Serializable]
public class CobblestoneSlab : HalfBlock
{

    public CobblestoneSlab(int x, int y, int z, bool up) : base(x,y,z,up)
    {
    }

    public override Tile TexturePosition(Direction direction)
	{
		Tile tile = new Tile();
		tile.x = 0;
		tile.y = 0;
		return tile;
	}

}