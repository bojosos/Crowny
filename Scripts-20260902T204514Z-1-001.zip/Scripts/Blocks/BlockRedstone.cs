﻿using UnityEngine;
using System;

[Serializable]
public class BlockRedstone : Block
{

    public BlockRedstone(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}