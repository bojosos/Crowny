﻿using UnityEngine;
using UnityEngine.UI;

public class WorldElement : MonoBehaviour
{
    
    public Text worldName;
    public Text lastPlayed;
    public Text seed;
    public Text gameMode;

    public void SetInfo(string wn, string lp, string s, string gm)
    {
        worldName.text = wn;
        lastPlayed.text = lp;
        seed.text = s;
        gameMode.text = gm;
    }

}

