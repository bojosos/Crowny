﻿using UnityEngine;
using System.Collections.Generic;

public class World : MonoBehaviour
{
    public Dictionary<WorldPos, Chunk> chunks = new Dictionary<WorldPos, Chunk>();

    public GameObject chunkPrefab;

    public string worldName = "world";
    
    public void CreateChunk(int x, int y, int z)
    {
        WorldPos worldPos = new WorldPos(x, y, z);

        GameObject newChunkObject = Instantiate(
                                        chunkPrefab, Vector3.zero,
                                        Quaternion.Euler(Vector3.zero)
                                    ) as GameObject;

        Chunk newChunk = newChunkObject.GetComponent<Chunk>();

        Debug.Log(worldPos.x + " " + worldPos.z);

        newChunk.pos = worldPos;
        newChunk.world = this;
        chunks.Add(worldPos, newChunk);

        var Generator = new Generator();
        newChunk = Generator.ChunkGen(newChunk);

        newChunk.SetBlocksUnmodified();

        //Serialization.Load(newChunk);
    }

    public void DestroyChunk(int x, int y, int z)
    {
        Chunk chunk = null;
        if (chunks.TryGetValue(new WorldPos(x, y, z), out chunk))
        {
            Serialization.SaveChunk(chunk);
            Object.Destroy(chunk.gameObject);
            chunks.Remove(new WorldPos(x, y, z));
        }
    }

    public Chunk GetChunk(int x, int y, int z)
    {
        WorldPos pos = new WorldPos();
        float multiple = Chunk.chunkSize;
        pos.x = Mathf.FloorToInt(x / multiple) * Chunk.chunkSize;
        pos.y = Mathf.FloorToInt(y / (float)Chunk.chunkHeight) * Chunk.chunkHeight;
        pos.z = Mathf.FloorToInt(z / multiple) * Chunk.chunkSize;

        Chunk containerChunk = null;

        chunks.TryGetValue(pos, out containerChunk);

        return containerChunk;
    }

    public Block GetBlock(int x, int y, int z)
    {
        Chunk containerChunk = GetChunk(x, y, z);

        if (containerChunk != null)
        {
            Block block = containerChunk.GetBlock(x, y, z);

            return block;
        }
        else
        {
            return new BlockAir(x,y,z);
        }

    }
    
    public void SetBlock(Block block)
    {
        Chunk chunk = GetChunk(block.x, block.y, block.z);

        if (chunk != null)
        {
            chunk.SetBlock(block);
            chunk.update = true;

            UpdateIfEqual(block.x - chunk.pos.x, 0, new WorldPos(block.x - 1, block.y, block.z));
            UpdateIfEqual(block.x - chunk.pos.x, Chunk.chunkSize - 1, new WorldPos(block.x + 1, block.y, block.z));
            UpdateIfEqual(block.y - chunk.pos.y, 0, new WorldPos(block.x, block.y - 1, block.z));
            UpdateIfEqual(block.y - chunk.pos.y, Chunk.chunkHeight - 1, new WorldPos(block.x, block.y + 1, block.z));
            UpdateIfEqual(block.z - chunk.pos.z, 0, new WorldPos(block.x, block.y, block.z - 1));
            UpdateIfEqual(block.z - chunk.pos.z, Chunk.chunkSize - 1, new WorldPos(block.x, block.y, block.z + 1));

        }
    }

    void UpdateIfEqual(int value1, int value2, WorldPos pos)
    {
        if (value1 == value2)
        {
            Chunk chunk = GetChunk(pos.x, pos.y, pos.z);
            if (chunk != null)
                chunk.update = true;
        }
    }
}
