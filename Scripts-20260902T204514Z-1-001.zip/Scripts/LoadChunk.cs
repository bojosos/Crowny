﻿using UnityEngine;
using System.Collections.Generic;

public class LoadChunk : MonoBehaviour
{
    
    static WorldPos[] chunkPositions =
		{ new WorldPos (0, 0, 0) };//, new WorldPos(-1, 0, 0), new WorldPos(0, 0, -1), new WorldPos(0, 0, 1), new WorldPos(1, 0, 0),
         /*   new WorldPos(-1, 0, -1), new WorldPos(-1, 0, 1), new WorldPos(1, 0, -1), new WorldPos(1, 0, 1), new WorldPos(-2, 0, 0),
            new WorldPos(0, 0, -2), new WorldPos(0, 0, 2), new WorldPos(2, 0, 0), new WorldPos(-2, 0, -1), new WorldPos(-2, 0, 1),
            new WorldPos(-1, 0, -2), new WorldPos(-1, 0, 2), new WorldPos(1, 0, -2), new WorldPos(1, 0, 2), new WorldPos(2, 0, -1),
            new WorldPos(2, 0, 1), new WorldPos(-2, 0, -2), new WorldPos(-2, 0, 2), new WorldPos(2, 0, -2), new WorldPos(2, 0, 2),
            new WorldPos(-3, 0, 0), new WorldPos(0, 0, -3), new WorldPos(0, 0, 3), new WorldPos(3, 0, 0), new WorldPos(-3, 0, -1),
            new WorldPos(-3, 0, 1), new WorldPos(-1, 0, -3), new WorldPos(-1, 0, 3), new WorldPos(1, 0, -3), new WorldPos(1, 0, 3),
            new WorldPos(3, 0, -1), new WorldPos(3, 0, 1), new WorldPos(-3, 0, -2), new WorldPos(-3, 0, 2), new WorldPos(-2, 0, -3),
            new WorldPos(-2, 0, 3), new WorldPos(2, 0, -3), new WorldPos(2, 0, 3), new WorldPos(3, 0, -2), new WorldPos(3, 0, 2),
            new WorldPos(-4, 0, 0), new WorldPos(0, 0, -4), new WorldPos(0, 0, 4), new WorldPos(4, 0, 0), new WorldPos(-4, 0, -1),
            new WorldPos(-4, 0, 1), new WorldPos(-1, 0, -4), new WorldPos(-1, 0, 4), new WorldPos(1, 0, -4), new WorldPos(1, 0, 4),
            new WorldPos(4, 0, -1), new WorldPos(4, 0, 1), new WorldPos(-3, 0, -3), new WorldPos(-3, 0, 3), new WorldPos(3, 0, -3),
            new WorldPos(3, 0, 3), new WorldPos(-4, 0, -2), new WorldPos(-4, 0, 2), new WorldPos(-2, 0, -4), new WorldPos(-2, 0, 4),
            new WorldPos(2, 0, -4), new WorldPos(2, 0, 4), new WorldPos(4, 0, -2), new WorldPos(4, 0, 2), new WorldPos(-5, 0, 0),
            new WorldPos(-4, 0, -3), new WorldPos(-4, 0, 3), new WorldPos(-3, 0, -4), new WorldPos(-3, 0, 4), new WorldPos(0, 0, -5),
            new WorldPos(0, 0, 5), new WorldPos(3, 0, -4), new WorldPos(3, 0, 4), new WorldPos(4, 0, -3), new WorldPos(4, 0, 3),
            new WorldPos(5, 0, 0), new WorldPos(-5, 0, -1), new WorldPos(-5, 0, 1), new WorldPos(-1, 0, -5), new WorldPos(-1, 0, 5),
            new WorldPos(1, 0, -5), new WorldPos(1, 0, 5), new WorldPos(5, 0, -1), new WorldPos(5, 0, 1), new WorldPos(-5, 0, -2),
            new WorldPos(-5, 0, 2), new WorldPos(-2, 0, -5), new WorldPos(-2, 0, 5), new WorldPos(2, 0, -5), new WorldPos(2, 0, 5),
            new WorldPos(5, 0, -2), new WorldPos(5, 0, 2), new WorldPos(-4, 0, -4), new WorldPos(-4, 0, 4), new WorldPos(4, 0, -4),
            new WorldPos(4, 0, 4), new WorldPos(-5, 0, -3), new WorldPos(-5, 0, 3), new WorldPos(-3, 0, -5), new WorldPos(-3, 0, 5),
            new WorldPos(3, 0, -5), new WorldPos(3, 0, 5), new WorldPos(5, 0, -3), new WorldPos(5, 0, 3), new WorldPos(-6, 0, 0),
            new WorldPos(0, 0, -6), new WorldPos(0, 0, 6), new WorldPos(6, 0, 0), new WorldPos(-6, 0, -1), new WorldPos(-6, 0, 1),
            new WorldPos(-1, 0, -6), new WorldPos(-1, 0, 6), new WorldPos(1, 0, -6), new WorldPos(1, 0, 6), new WorldPos(6, 0, -1),
            new WorldPos(6, 0, 1), new WorldPos(-6, 0, -2), new WorldPos(-6, 0, 2), new WorldPos(-2, 0, -6), new WorldPos(-2, 0, 6),
            new WorldPos(2, 0, -6), new WorldPos(2, 0, 6), new WorldPos(6, 0, -2), new WorldPos(6, 0, 2), new WorldPos(-5, 0, -4),
            new WorldPos(-5, 0, 4), new WorldPos(-4, 0, -5), new WorldPos(-4, 0, 5), new WorldPos(4, 0, -5), new WorldPos(4, 0, 5),
            new WorldPos(5, 0, -4), new WorldPos(5, 0, 4), new WorldPos(-6, 0, -3), new WorldPos(-6, 0, 3), new WorldPos(-3, 0, -6),
            new WorldPos(-3, 0, 6), new WorldPos(3, 0, -6), new WorldPos(3, 0, 6), new WorldPos(6, 0, -3), new WorldPos(6, 0, 3),
            new WorldPos(-7, 0, 0), new WorldPos(0, 0, -7), new WorldPos(0, 0, 7), new WorldPos(7, 0, 0), new WorldPos(-7, 0, -1),
            new WorldPos(-7, 0, 1), new WorldPos(-5, 0, -5), new WorldPos(-5, 0, 5), new WorldPos(-1, 0, -7), new WorldPos(-1, 0, 7),
            new WorldPos(1, 0, -7), new WorldPos(1, 0, 7), new WorldPos(5, 0, -5), new WorldPos(5, 0, 5), new WorldPos(7, 0, -1),
            new WorldPos(7, 0, 1), new WorldPos(-6, 0, -4), new WorldPos(-6, 0, 4), new WorldPos(-4, 0, -6), new WorldPos(-4, 0, 6),
            new WorldPos(4, 0, -6), new WorldPos(4, 0, 6), new WorldPos(6, 0, -4), new WorldPos(6, 0, 4), new WorldPos(-7, 0, -2),
            new WorldPos(-7, 0, 2), new WorldPos(-2, 0, -7), new WorldPos(-2, 0, 7), new WorldPos(2, 0, -7), new WorldPos(2, 0, 7),
            new WorldPos(7, 0, -2), new WorldPos(7, 0, 2), new WorldPos(-7, 0, -3), new WorldPos(-7, 0, 3), new WorldPos(-3, 0, -7),
            new WorldPos(-3, 0, 7), new WorldPos(3, 0, -7), new WorldPos(3, 0, 7), new WorldPos(7, 0, -3), new WorldPos(7, 0, 3),
            new WorldPos(-6, 0, -5), new WorldPos(-6, 0, 5), new WorldPos(-5, 0, -6), new WorldPos(-5, 0, 6), new WorldPos(5, 0, -6),
            new WorldPos(5, 0, 6), new WorldPos(6, 0, -5), new WorldPos(6, 0, 5)
        };*/
    /*
    static WorldPos[] chunkPositions =
        {   new WorldPos(0, 0, 0), new WorldPos(-1, 0, 0), new WorldPos(0, 0, -1), new WorldPos(0, 0, 1), new WorldPos(1, 0, 0),
        new WorldPos(-1, 0, -1), new WorldPos(-1, 0, 1), new WorldPos(1, 0, -1), new WorldPos(1, 0, 1), new WorldPos(-2, 0, 0),
        new WorldPos(0, 0, -2), new WorldPos(0, 0, 2), new WorldPos(2, 0, 0), new WorldPos(-2, 0, -1), new WorldPos(-2, 0, 1),
        new WorldPos(-1, 0, -2), new WorldPos(-1, 0, 2), new WorldPos(1, 0, -2), new WorldPos(1, 0, 2), new WorldPos(2, 0, -1),
        new WorldPos(2, 0, 1), new WorldPos(-2, 0, -2), new WorldPos(-2, 0, 2), new WorldPos(2, 0, -2), new WorldPos(2, 0, 2),
        new WorldPos(-3, 0, 0), new WorldPos(0, 0, -3), new WorldPos(0, 0, 3), new WorldPos(3, 0, 0), new WorldPos(-3, 0, -1),
        new WorldPos(-3, 0, 1), new WorldPos(-1, 0, -3), new WorldPos(-1, 0, 3), new WorldPos(1, 0, -3), new WorldPos(1, 0, 3),
        new WorldPos(3, 0, -1), new WorldPos(3, 0, 1), new WorldPos(-3, 0, -2), new WorldPos(-3, 0, 2), new WorldPos(-2, 0, -3),
        new WorldPos(-2, 0, 3), new WorldPos(2, 0, -3), new WorldPos(2, 0, 3), new WorldPos(3, 0, -2), new WorldPos(3, 0, 2),
        new WorldPos(-4, 0, 0), new WorldPos(0, 0, -4), new WorldPos(0, 0, 4), new WorldPos(4, 0, 0), new WorldPos(-4, 0, -1),
        new WorldPos(-4, 0, 1), new WorldPos(-1, 0, -4), new WorldPos(-1, 0, 4), new WorldPos(1, 0, -4), new WorldPos(1, 0, 4),
        new WorldPos(4, 0, -1), new WorldPos(4, 0, 1), new WorldPos(-3, 0, -3), new WorldPos(-3, 0, 3), new WorldPos(3, 0, -3),
        new WorldPos(3, 0, 3), new WorldPos(-4, 0, -2), new WorldPos(-4, 0, 2), new WorldPos(-2, 0, -4), new WorldPos(-2, 0, 4),
        new WorldPos(2, 0, -4), new WorldPos(2, 0, 4), new WorldPos(4, 0, -2), new WorldPos(4, 0, 2), new WorldPos(-5, 0, 0),
        new WorldPos(-4, 0, -3), new WorldPos(-4, 0, 3), new WorldPos(-3, 0, -4), new WorldPos(-3, 0, 4), new WorldPos(0, 0, -5),
        new WorldPos(0, 0, 5), new WorldPos(3, 0, -4), new WorldPos(3, 0, 4), new WorldPos(4, 0, -3), new WorldPos(4, 0, 3),
        new WorldPos(5, 0, 0), new WorldPos(-5, 0, -1), new WorldPos(-5, 0, 1), new WorldPos(-1, 0, -5), new WorldPos(-1, 0, 5),
        new WorldPos(1, 0, -5), new WorldPos(1, 0, 5), new WorldPos(5, 0, -1), new WorldPos(5, 0, 1), new WorldPos(-5, 0, -2),
        new WorldPos(-5, 0, 2), new WorldPos(-2, 0, -5), new WorldPos(-2, 0, 5), new WorldPos(2, 0, -5), new WorldPos(2, 0, 5),
        new WorldPos(5, 0, -2), new WorldPos(5, 0, 2), new WorldPos(-4, 0, -4), new WorldPos(-4, 0, 4), new WorldPos(4, 0, -4),
        new WorldPos(4, 0, 4), new WorldPos(-5, 0, -3), new WorldPos(-5, 0, 3), new WorldPos(-3, 0, -5), new WorldPos(-3, 0, 5),
        new WorldPos(3, 0, -5), new WorldPos(3, 0, 5), new WorldPos(5, 0, -3), new WorldPos(5, 0, 3), new WorldPos(-6, 0, 0),
        new WorldPos(0, 0, -6), new WorldPos(0, 0, 6), new WorldPos(6, 0, 0), new WorldPos(-6, 0, -1), new WorldPos(-6, 0, 1),
        new WorldPos(-1, 0, -6), new WorldPos(-1, 0, 6), new WorldPos(1, 0, -6), new WorldPos(1, 0, 6), new WorldPos(6, 0, -1),
        new WorldPos(6, 0, 1), new WorldPos(-6, 0, -2), new WorldPos(-6, 0, 2), new WorldPos(-2, 0, -6), new WorldPos(-2, 0, 6),
        new WorldPos(2, 0, -6), new WorldPos(2, 0, 6), new WorldPos(6, 0, -2), new WorldPos(6, 0, 2), new WorldPos(-5, 0, -4),
        new WorldPos(-5, 0, 4), new WorldPos(-4, 0, -5), new WorldPos(-4, 0, 5), new WorldPos(4, 0, -5), new WorldPos(4, 0, 5),
        new WorldPos(5, 0, -4), new WorldPos(5, 0, 4), new WorldPos(-6, 0, -3), new WorldPos(-6, 0, 3), new WorldPos(-3, 0, -6),
        new WorldPos(-3, 0, 6), new WorldPos(3, 0, -6), new WorldPos(3, 0, 6), new WorldPos(6, 0, -3), new WorldPos(6, 0, 3),
        new WorldPos(-5, 0, -5), new WorldPos(-5, 0, 5), new WorldPos(5, 0, -5), new WorldPos(5, 0, 5),
        new WorldPos(-6, 0, -4), new WorldPos(-6, 0, 4), new WorldPos(-4, 0, -6), new WorldPos(-4, 0, 6),
        new WorldPos(4, 0, -6), new WorldPos(4, 0, 6), new WorldPos(6, 0, -4), new WorldPos(6, 0, 4),
        new WorldPos(-6, 0, -5), new WorldPos(-6, 0, 5), new WorldPos(-5, 0, -6), new WorldPos(-5, 0, 6), new WorldPos(5, 0, -6),
        new WorldPos(5, 0, 6), new WorldPos(6, 0, -5), new WorldPos(6, 0, 5)
    };*/

    void Start()
    {
        world = GameObject.Find("World").GetComponent<World>();
    }

    public World world;

    Queue<WorldPos> updateList = new Queue<WorldPos>();
    Queue<WorldPos> buildList = new Queue<WorldPos>();

    int timer = 0;

    void Update()
    {
        if (DeleteChunks())
            return;
        FindChunksToLoad();
        LoadAndRenderChunks();
    }

    void FindChunksToLoad()
    {
        WorldPos playerPos = new WorldPos(
                                 Mathf.FloorToInt(transform.position.x / Chunk.chunkSize) * Chunk.chunkSize,
                                 Mathf.FloorToInt(transform.position.y / Chunk.chunkHeight) * Chunk.chunkHeight,
                                 Mathf.FloorToInt(transform.position.z / Chunk.chunkSize) * Chunk.chunkSize
                             );

        if (updateList.Count == 0)
        {
            for (int i = 0; i < chunkPositions.Length; i++)
            {
                WorldPos newChunkPos = new WorldPos(
                                           chunkPositions[i].x * Chunk.chunkSize + playerPos.x,
                                           0,
                                           chunkPositions[i].z * Chunk.chunkSize + playerPos.z
                                       );

                Chunk newChunk = world.GetChunk(
                                     newChunkPos.x, newChunkPos.y, newChunkPos.z);

                if (newChunk != null
                    && ((newChunk.rendered) || updateList.Contains(newChunkPos)))
                    continue;
                for (int x = newChunkPos.x - Chunk.chunkSize; x <= newChunkPos.x + Chunk.chunkSize; x += Chunk.chunkSize)
                {
                    for (int z = newChunkPos.z - Chunk.chunkSize; z <= newChunkPos.z + Chunk.chunkSize; z += Chunk.chunkSize)
                    {
                        buildList.Enqueue(new WorldPos(
                                x, 0 * Chunk.chunkHeight, z));
                    }
                }
                updateList.Enqueue(new WorldPos(
                        newChunkPos.x, 0 * Chunk.chunkHeight, newChunkPos.z));
                return;
            }
        }
    }

    void LoadAndRenderChunks()
    {
        if (buildList.Count != 0)
        {
            for (int i = 0; i < buildList.Count && i < 8; i++)
            {
                BuildChunk(buildList.Dequeue());
            }
            return;
        }
        if (updateList.Count != 0)
        {
            WorldPos pos = updateList.Peek();
            Chunk chunk = world.GetChunk(pos.x, pos.y, pos.z);
            if (chunk != null)
                chunk.update = true;
            updateList.Dequeue();
        }
    }

    void BuildChunk(WorldPos pos)
    {
		if (world.GetChunk (pos.x, pos.y, pos.z) == null) {
            world.CreateChunk(pos.x, pos.y, pos.z);
		}
    }

    bool DeleteChunks()
    {
        if (timer == 1)
        {
            var chunksToDelete = new List<WorldPos>();
            foreach (var chunk in world.chunks)
            {
                float distance = Vector3.Distance(
                                     new Vector3(chunk.Value.pos.x, 0, chunk.Value.pos.z),
                                     new Vector3(transform.position.x, 0, transform.position.z));
                if (distance > 512)
                    chunksToDelete.Add(chunk.Key);
            }
            foreach (var chunk in chunksToDelete)
                world.DestroyChunk(chunk.x, chunk.y, chunk.z);
            timer = 0;
            return true;
        }
        timer++;
        return false;
    }
}